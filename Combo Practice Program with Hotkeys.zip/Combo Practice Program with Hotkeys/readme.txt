open the combo folder and open combo.exe. 

use 9 to indicate a successful attempt, and 0 to indicate a failed one. make sure numlock is on if you use numpad

rest should be self explanatory

play ries