open the combo folder and open combo.exe. 

rest should be self explanatory

play ries